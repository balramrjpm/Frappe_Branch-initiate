# Copyright (c) 2024, Balram Singh and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class ProductLineDetails(Document):
	pass
