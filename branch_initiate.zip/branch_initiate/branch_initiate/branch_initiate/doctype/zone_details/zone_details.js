// Copyright (c) 2024, Balram Singh and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Zone Details", {
// 	refresh(frm) {

// 	},
// });
